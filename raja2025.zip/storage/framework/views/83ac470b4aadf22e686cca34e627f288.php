<div>
    <h2 class="mb-4 text-lg font-semibold">Kategori Aset</h2>

    <form wire:submit.prevent="save" class="space-y-2">
        <input type="text" wire:model.defer="name" placeholder="Nama kategori" class="w-full p-2 border" />
        <button type="submit" class="px-4 py-1 text-white bg-blue-500 rounded"><?php echo e($editId ? 'Update' : 'Tambah'); ?></button>
    </form>

    <ul class="mt-4 space-y-1">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="flex justify-between p-2 border">
                <?php echo e($item->name); ?>

                <span>
                    <button wire:click="edit(<?php echo e($item->id); ?>)" class="text-sm text-blue-600">Edit</button>
                    <button wire:click="delete(<?php echo e($item->id); ?>)" class="text-sm text-red-600">Hapus</button>
                </span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </ul>
</div>
<?php /**PATH S:\project jalan\raja2025\resources\views/livewire/master/asset-management/asset-category-manager.blade.php ENDPATH**/ ?>