<div>
    <h2 class="mb-4 text-lg font-semibold">Vendor</h2>

    <form wire:submit.prevent="save" class="grid grid-cols-2 gap-2">
        <input type="text" wire:model.defer="name" placeholder="Nama vendor" class="p-2 border" />
        <input type="text" wire:model.defer="contact_person" placeholder="Kontak person" class="p-2 border" />
        <input type="text" wire:model.defer="phone" placeholder="Telepon" class="p-2 border" />
        <input type="email" wire:model.defer="email" placeholder="Email" class="p-2 border" />
        <textarea wire:model.defer="address" placeholder="Alamat" class="col-span-2 p-2 border"></textarea>
        <textarea wire:model.defer="notes" placeholder="Catatan" class="col-span-2 p-2 border"></textarea>
        <button type="submit" class="col-span-2 px-4 py-1 text-white bg-blue-500 rounded"><?php echo e($editId ? 'Update' : 'Tambah'); ?></button>
    </form>

    <ul class="mt-4 space-y-1">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="flex justify-between p-2 border">
                <?php echo e($vendor->name); ?> - <?php echo e($vendor->email); ?>

                <span>
                    <button wire:click="edit(<?php echo e($vendor->id); ?>)" class="text-sm text-blue-600">Edit</button>
                    <button wire:click="delete(<?php echo e($vendor->id); ?>)" class="text-sm text-red-600">Hapus</button>
                </span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </ul>
</div>
<?php /**PATH S:\project jalan\raja2025\resources\views/livewire/master/core/vendor-manager.blade.php ENDPATH**/ ?>