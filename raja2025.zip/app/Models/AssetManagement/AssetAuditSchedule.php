<?php

namespace App\Models\AssetManagement;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AssetAuditSchedule extends Model
{
    /** @use HasFactory<\Database\Factories\AssetAuditScheduleFactory> */
    use HasFactory;
}
