<?php

namespace App\Models\AssetManagement;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AssetAudit extends Model
{
    /** @use HasFactory<\Database\Factories\AssetAuditFactory> */
    use HasFactory;
}
