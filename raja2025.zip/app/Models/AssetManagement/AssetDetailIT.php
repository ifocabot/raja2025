<?php

namespace App\Models\AssetManagement;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AssetDetailIT extends Model
{
    /** @use HasFactory<\Database\Factories\AssetDetailITMFactory> */
    use HasFactory;
}
